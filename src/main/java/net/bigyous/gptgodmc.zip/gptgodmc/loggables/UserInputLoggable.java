package net.bigyous.gptgodmc.loggables;

public interface UserInputLoggable {
    public void updateUserInput(String input);
}
