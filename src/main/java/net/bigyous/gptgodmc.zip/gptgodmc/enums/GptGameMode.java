package net.bigyous.gptgodmc.enums;

public enum GptGameMode {
    SANDBOX,
    DEATHMATCH
}
