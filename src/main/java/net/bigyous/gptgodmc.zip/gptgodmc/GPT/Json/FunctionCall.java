package net.bigyous.gptgodmc.GPT.Json;

public class FunctionCall {
    private String name;
    private String arguments;

    public String getArguments() {
        return arguments;
    }

    public String getName() {
        return name;
    }
}
